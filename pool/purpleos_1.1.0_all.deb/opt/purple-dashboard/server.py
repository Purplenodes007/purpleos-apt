#!/usr/bin/env python3
import json
import os
import time
import secrets
import hashlib
import hmac
import shutil
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs
from http.cookies import SimpleCookie

HOST = "127.0.0.1"
PORT = 8765
AUTH_FILE = "/etc/purple-dashboard/auth.json"
SESSIONS = {}
FAILURES = {}
LOCK = threading.Lock()
SESSION_SECONDS = 1800
LAST_CPU = None
LAST_NET = None
LAST_NET_TIME = time.time()

HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Purple OS Control Center</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b0912;color:#eeeaf8;font:14px Arial}
#login{min-height:100vh;display:grid;place-items:center}
.loginbox{width:min(390px,92%);background:#171222;border:1px solid #49305e;border-radius:16px;padding:30px}
h1{color:#d8a5ff;margin:0 0 8px}.muted{color:#a99bb9}
input{width:100%;padding:13px;margin:9px 0;background:#0d0a14;border:1px solid #49305e;border-radius:8px;color:white}
button{padding:12px 16px;background:#9333ea;color:white;border:0;border-radius:8px;cursor:pointer}
.loginbox button{width:100%;margin-top:10px}.error{color:#fb7185;min-height:20px}
#app{display:none}.sidebar{position:fixed;inset:0 auto 0 0;width:225px;background:#130e1d;border-right:1px solid #30213f;padding:24px 15px}
.brand{font-size:21px;font-weight:bold;color:#d8a5ff;padding:5px 10px 28px}
.nav{display:block;padding:13px 12px;color:#c8bbd6;border-radius:8px;margin:5px 0}
.nav.active,.nav:hover{background:#39204f;color:white}
.main{margin-left:225px;padding:25px 30px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
h2{margin:0;font-size:23px}.online{color:#4ade80;margin-top:8px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin-top:25px}
.card{background:#171222;border:1px solid #30213f;border-radius:12px;padding:20px}
.card h3{font-size:12px;color:#b8a9c8;margin:0 0 18px}
.value{font-size:29px;font-weight:bold;color:#e9d5ff}.sub{color:#a99bb9;margin-top:9px;font-size:12px}
.track{height:8px;background:#30213f;border-radius:10px;margin-top:16px;overflow:hidden}
.fill{height:100%;background:linear-gradient(90deg,#9333ea,#e879f9);width:0}
.section{margin-top:20px}.section h3{color:#d8a5ff}
table{width:100%;border-collapse:collapse}td{padding:12px;border-bottom:1px solid #30213f;color:#c8bbd6}
@media(max-width:650px){.sidebar{position:static;width:auto;padding:12px}.brand{padding:8px}.nav{display:inline-block;padding:8px}.main{margin:0;padding:18px}}
</style>
</head>
<body>
<div id="login"><form class="loginbox" id="loginform">
<h1>💜 Purple OS</h1><p class="muted">Control Center · Secure Login</p>
<input name="username" placeholder="Username" autocomplete="username" required>
<input name="password" type="password" placeholder="Password" autocomplete="current-password" required>
<div class="error" id="error"></div><button>Sign in</button>
</form></div>
<div id="app">
<aside class="sidebar">
<div class="brand">💜 PURPLE OS</div>
<div class="nav active">▦ Datacenter</div>
<div class="nav">▣ Node · <span id="node">Purple OS</span></div>
<div class="nav">▤ Summary</div><div class="nav">◷ Monitoring</div>
<div class="nav">▧ Storage</div>
</aside>
<main class="main">
<div class="top"><div><h2>Datacenter Overview</h2><div class="online">● Node online · Monitoring active</div></div>
<button id="logout">Log out</button></div>
<div class="grid">
<div class="card"><h3>CPU USAGE</h3><div class="value" id="cpu">--%</div><div class="track"><div class="fill" id="cpuBar"></div></div></div>
<div class="card"><h3>MEMORY</h3><div class="value" id="ram">--%</div><div class="sub" id="ramDetail">Loading...</div><div class="track"><div class="fill" id="ramBar"></div></div></div>
<div class="card"><h3>ROOT STORAGE</h3><div class="value" id="disk">--%</div><div class="sub" id="diskDetail">Loading...</div><div class="track"><div class="fill" id="diskBar"></div></div></div>
<div class="card"><h3>UPTIME</h3><div class="value" id="uptime">--</div><div class="sub">Since system boot</div></div>
<div class="card"><h3>NETWORK RX</h3><div class="value" id="rx">--</div><div class="sub">Receive rate</div></div>
<div class="card"><h3>NETWORK TX</h3><div class="value" id="tx">--</div><div class="sub">Transmit rate</div></div>
</div>
<div class="card section"><h3>Node Information</h3><table>
<tr><td>Hostname</td><td id="hostname">--</td></tr>
<tr><td>Operating system</td><td id="os">Purple OS</td></tr>
<tr><td>Kernel</td><td id="kernel">--</td></tr>
<tr><td>Architecture</td><td id="arch">--</td></tr>
<tr><td>Virtualization</td><td id="virt">--</td></tr>
</table></div>
<p class="muted">Purple OS Control Center · Read-only monitoring · Refreshes every 3 seconds</p>
</main></div>
<script>
const $=id=>document.getElementById(id);
function showLogin(){ $('login').style.display='grid';$('app').style.display='none';}
function showApp(){ $('login').style.display='none';$('app').style.display='block';refresh();}
$('loginform').addEventListener('submit',async e=>{
 e.preventDefault();$('error').textContent='';
 const body=new URLSearchParams(new FormData(e.target));
 try{let r=await fetch('/login',{method:'POST',body,credentials:'same-origin'});
 if(r.ok){e.target.reset();showApp()}else{$('error').textContent='Login failed. Check username and password.'}}
 catch(_){$('error').textContent='Connection error'}
});
$('logout').onclick=async()=>{await fetch('/logout',{method:'POST',credentials:'same-origin'});showLogin()};
function bar(id,v){$(id).style.width=Math.max(0,Math.min(100,v))+'%'}
function fmt(n){if(n>=1073741824)return (n/1073741824).toFixed(2)+' GB';if(n>=1048576)return (n/1048576).toFixed(1)+' MB';return n+' B'}
async function refresh(){
 try{
  let r=await fetch('/api/stats',{cache:'no-store',credentials:'same-origin'});
  if(r.status===401){showLogin();return} if(!r.ok)throw Error();
  let d=await r.json();
  $('cpu').textContent=d.cpu+'%';bar('cpuBar',d.cpu);
  $('ram').textContent=d.ram.percent+'%';bar('ramBar',d.ram.percent);
  $('ramDetail').textContent=fmt(d.ram.used)+' / '+fmt(d.ram.total);
  $('disk').textContent=d.disk.percent+'%';bar('diskBar',d.disk.percent);
  $('diskDetail').textContent=fmt(d.disk.used)+' / '+fmt(d.disk.total);
  $('uptime').textContent=d.uptime;$('rx').textContent=d.network.rx;$('tx').textContent=d.network.tx;
  $('hostname').textContent=d.hostname;$('node').textContent=d.hostname;
  $('kernel').textContent=d.kernel;$('arch').textContent=d.arch;$('virt').textContent=d.virt;
 }catch(_){}
}
async function check(){try{let r=await fetch('/api/me');if(r.ok)showApp();else showLogin()}catch(_){showLogin()}}
check();setInterval(()=>{if($('app').style.display==='block')refresh()},3000);
</script>
</body></html>"""

def read_auth():
    with open(AUTH_FILE) as f:
        return json.load(f)

def authenticated(handler):
    cookie = SimpleCookie()
    cookie.load(handler.headers.get("Cookie", ""))
    morsel = cookie.get("purple_session")
    if not morsel:
        return False
    token = morsel.value
    with LOCK:
        expiry = SESSIONS.get(token)
        if not expiry:
            return False
        if expiry < time.time():
            SESSIONS.pop(token, None)
            return False
        SESSIONS[token] = time.time() + SESSION_SECONDS
    return True

def cpu_sample():
    with open("/proc/stat") as f:
        v = list(map(int, f.readline().split()[1:]))
    return sum(v), v[3] + v[4]

def rate(n):
    units = ["B/s", "KB/s", "MB/s", "GB/s"]
    for unit in units:
        if n < 1024 or unit == units[-1]:
            return f"{n:.1f} {unit}"
        n /= 1024

def stats():
    global LAST_CPU, LAST_NET, LAST_NET_TIME
    total, idle = cpu_sample()
    cpu = 0
    if LAST_CPU:
        dt, di = total-LAST_CPU[0], idle-LAST_CPU[1]
        if dt > 0:
            cpu = round(max(0, min(100, (dt-di)*100/dt)), 1)
    LAST_CPU = (total, idle)

    mem = {}
    with open("/proc/meminfo") as f:
        for line in f:
            k, v = line.split(":", 1)
            mem[k] = int(v.strip().split()[0]) * 1024
    mt = mem["MemTotal"]
    mu = mt - mem.get("MemAvailable", mem.get("MemFree", 0))

    du = shutil.disk_usage("/")
    rx = tx = 0
    with open("/proc/net/dev") as f:
        for line in f.readlines()[2:]:
            if ":" in line:
                name, data = line.split(":", 1)
                if name.strip() != "lo":
                    fields = data.split()
                    rx += int(fields[0]); tx += int(fields[8])
    now = time.time()
    elapsed = max(now-LAST_NET_TIME, .001)
    rr = tr = 0
    if LAST_NET:
        rr = max(0, rx-LAST_NET[0])/elapsed
        tr = max(0, tx-LAST_NET[1])/elapsed
    LAST_NET = (rx, tx); LAST_NET_TIME = now

    with open("/proc/uptime") as f:
        seconds = int(float(f.read().split()[0]))
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    uptime = f"{days}d {hours}h {seconds//60}m"

    try:
        with open("/proc/1/cgroup") as f:
            cg = f.read().lower()
        virt = "LXC" if "lxc" in cg else "Container/VM"
    except Exception:
        virt = "Unknown"

    u = os.uname()
    return {
        "cpu": cpu,
        "ram": {"total": mt, "used": mu, "percent": round(mu*100/mt, 1) if mt else 0},
        "disk": {"total": du.total, "used": du.used, "percent": round(du.used*100/du.total, 1)},
        "network": {"rx": rate(rr), "tx": rate(tr)},
        "uptime": uptime, "hostname": u.nodename, "kernel": u.release,
        "arch": u.machine, "virt": virt
    }

class Handler(BaseHTTPRequestHandler):
    def reply(self, code, body=b"", content_type="text/plain", headers=None):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.end_headers()
        if body:
            self.wfile.write(body)

    def do_GET(self):
        if self.path == "/login":
            self.reply(200, HTML.encode(), "text/html; charset=utf-8")
        elif self.path == "/api/me":
            self.reply(200 if authenticated(self) else 401, b"{}", "application/json")
        elif self.path == "/api/stats":
            if not authenticated(self):
                self.reply(401, b'{"error":"login required"}', "application/json")
            else:
                self.reply(200, json.dumps(stats()).encode(), "application/json")
        elif self.path == "/":
            if authenticated(self):
                self.reply(200, HTML.encode(), "text/html; charset=utf-8")
            else:
                self.reply(200, HTML.encode(), "text/html; charset=utf-8")
        else:
            self.reply(404, b"Not found")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > 4096:
            self.reply(413, b"Too large"); return
        data = self.rfile.read(length)
        if self.path == "/login":
            ip = self.client_address[0]
            with LOCK:
                if FAILURES.get(ip, (0, 0))[1] > time.time():
                    self.reply(429, b"Try again later"); return
            try:
                form = parse_qs(data.decode())
                username = form.get("username", [""])[0]
                password = form.get("password", [""])[0]
                auth = read_auth()
                salt = bytes.fromhex(auth["salt"])
                test = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(auth["iterations"]))
                valid = hmac.compare_digest(username, auth["username"]) and hmac.compare_digest(test.hex(), auth["password_hash"])
            except Exception:
                valid = False
            if not valid:
                with LOCK:
                    count, until = FAILURES.get(ip, (0, 0))
                    count += 1
                    FAILURES[ip] = (count, time.time()+300 if count >= 5 else 0)
                self.reply(401, b"Login failed"); return
            with LOCK:
                FAILURES.pop(ip, None)
            token = secrets.token_urlsafe(32)
            with LOCK:
                SESSIONS[token] = time.time()+SESSION_SECONDS
            self.reply(200, b"OK", headers={"Set-Cookie": f"purple_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_SECONDS}"})
        elif self.path == "/logout":
            cookie = SimpleCookie()
            cookie.load(self.headers.get("Cookie", ""))
            morsel = cookie.get("purple_session")
            if morsel:
                with LOCK:
                    SESSIONS.pop(morsel.value, None)
            self.reply(200, b"OK", headers={"Set-Cookie": "purple_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"})
        else:
            self.reply(404, b"Not found")

    def log_message(self, fmt, *args):
        pass

if __name__ == "__main__":
    if not os.path.isfile(AUTH_FILE):
        raise SystemExit("Login not configured. Run purple-dashboard-setup first.")
    print(f"Purple OS Control Center listening on {HOST}:{PORT}", flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
