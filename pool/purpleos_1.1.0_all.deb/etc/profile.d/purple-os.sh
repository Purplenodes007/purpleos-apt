case "$-" in
    *i*) /usr/bin/purplefetch ;;
esac
